'use strict';
var Alexa = require('alexa-sdk');

var APP_ID = undefined; //OPTIONAL: replace with "amzn1.echo-sdk-ams.app.[your-unique-value-here]";
var SKILL_NAME = 'Wine Facts';

/**
 * Array containing space facts.
 */
var FACTS = [
    "Wine is delicious by default.",
    "Wine is as easy to make as leaving a jug of juice alone in a dark closet.",
    "Humans began agriculture in order to cultivate wine grapes.",
    "Wine is a safer alternative to drink than engine coolant.",
    "Every culture in the world has their own version of wine.",
    "Drinking moderate amounts of wine each day can lead to having fun.",
    "Any grain, fruit, or vegetable can be turned into a wine.",
    "The drinking age for wine in America is 21 years",
    "Wine is made from grapes, yeast, and water",
    "Wine is great.  Have some wine today."
];

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
        this.emit('GetFact');
    },
    'GetNewFactIntent': function () {
        this.emit('GetFact');
    },
    'GetFact': function () {
        // Get a random space fact from the space facts list
        var factIndex = Math.floor(Math.random() * FACTS.length);
        var randomFact = FACTS[factIndex];

        // Create speech output
        var speechOutput = "Here's your fact: " + randomFact;

        this.emit(':tellWithCard', speechOutput, SKILL_NAME, randomFact)
    },
    'AMAZON.HelpIntent': function () {
        var speechOutput = "You can say tell me a wine fact, or, you can say stop... How can I help?";
        var reprompt = "Did you have a question?";
        this.emit(':ask', speechOutput, reprompt);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', 'Goodbye!');
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', 'Goodbye!');
    }
};
